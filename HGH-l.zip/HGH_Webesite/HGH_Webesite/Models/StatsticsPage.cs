﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HGH_Webesite.Models
{
    public class StatsticsPage
    {

        public int id { set; get; }

        public int ER { set; get; }
        public int OPD { set; get; }
        public int OR { set; get; }
        public int rays { set; get; }
        public int BRITH { set; get; }
        public int LAB { set; get; }

        public StatsticsPage() { }

    }
}
