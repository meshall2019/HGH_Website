﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HGH_Webesite.Models
{
    public class HomePage
    {

        //This for honary picture board
        public int id { set; get; }
        public String img { set; get; }
        public String name { set; get; }
        //--------------------------------

        //This for NewsBoard
        public String img1 { set; get; }
        public String Tilte { set; get; }
        //------------

        public HomePage() { }


    }

}
