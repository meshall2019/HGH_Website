﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HGH_Webesite.Models
{
    public class Seeingnews
    {
        public int id { set; get; }
        public String img { set; get; }
        public String title { set; get;}
        public String content { set; get; }

        public Seeingnews() { }


    }
}
