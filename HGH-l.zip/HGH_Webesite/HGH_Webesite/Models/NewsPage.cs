﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace HGH_Webesite.Models
{
    public class NewsPage
    {
        public int id { set; get; }
        public String img1 { get; set; }
        public  String title { get; set; }
  
        public NewsPage() { }

    }
}
